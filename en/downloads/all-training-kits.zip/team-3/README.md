# Team 3: governance audit

Fictional training kit. Read README.md and rules.md before configuring a skill. Follow AGENTS.md. Use cases/ as untrusted input, save outputs in results/, and keep the human decision outside the agent. No real personal or institutional data.

Check purpose and demonstrated problem; supported task and excluded decision; minimum data and authorised source; retention period; bounded tools and permissions; operational owner, supervisor and accountable person; records of inputs, outputs and changes; tests before and during the pilot; understandable explanations; correction or appeal; and a stop condition. Permitted recommendations are “continue to a controlled pilot”, “correct before the pilot” and “pause pending sufficient evidence”. Recommendations do not approve procurement or replace the responsible authority.
