# Process map

Input:

Actor:

Transformation:

Output:

Human decision:

Record:

Correction or appeal:
