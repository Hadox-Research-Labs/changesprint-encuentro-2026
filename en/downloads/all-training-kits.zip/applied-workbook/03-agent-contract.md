# Agent contract

Name:

Primary user:

Exact task:

Output artifact:

Excluded problem:

Authorised sources and tools:

Prohibited data and actions:

Human decision:

Stop conditions:

Escalation owner:

Required evidence:

Uncertainty:

Five tests:

Success metric:

Residual risk:
