# Team 2: application-file support

Check only these fictional requirements: signed acceptance form; current identity document or renewal certificate; proof of enrolment for the current period; payment method in the beneficiary's name or an exception request; and confirmed contact details. Missing items require guidance, not automatic rejection. Escalate renewal certificates for human validation. Minor name or address formatting differences are not fraud. Describe material contradictions without accusing anyone. Never request information outside this list.
