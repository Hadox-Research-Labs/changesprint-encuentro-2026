# Test log

| Case | Expected result | Observed result | Risk | Correction | Rerun | Residual risk |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
