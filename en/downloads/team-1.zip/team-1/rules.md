# Team 1: essay review

Validate that the essay and rubric exist. Extract relevant evidence, assess each criterion, justify each judgement, identify gaps and escalate borderline cases. The artifact supports human review; it never awards or denies a scholarship.

Fictional rubric: 0 = no relevant evidence; 1 = weak evidence, mentioning a criterion without a concrete example or clear relationship; 2 = sufficient evidence, with an example and understandable connection; 3 = strong evidence integrating examples, reflection and a clear connection to the objective. Assess four criteria: clarity of educational or professional purpose; experience evidenced within the essay; relationship between support and purpose; and reflection on obstacles, learning and next steps. Do not assess literary style, accent or spelling. Do not infer financial need. Do not total the criteria into a final selection score. Escalate if two criteria depend on absent or ambiguous information.
