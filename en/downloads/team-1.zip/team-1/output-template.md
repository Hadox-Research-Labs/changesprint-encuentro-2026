# Output template and test log

For each case record: fictional identifier; review status; observed facts; criterion or requirement; evidence excerpt and filename; assessment and justification; missing information; uncertainty; risks; recommendation; human escalation reason and owner. Team 1 also records evidence level 0–3 for each of the four criteria, without a total selection score. Team 2 records each requirement as present, missing, contradictory or requiring human validation. Team 3 records each control as evidenced, missing or unclear and issues one permitted recommendation.

In the test log use: case; expected result; observed result; failure or risk; correction; rerun result; residual risk. A passing test needs evidence. It is acceptable to record a failure; an unexamined claim of success is not enough.
